function Sources({ sources }) {
  const uniqueSources = sources.filter(
    (source, index, array) =>
      index ===
      array.findIndex(
        (item) =>
          item.source === source.source &&
          item.chunk_id === source.chunk_id
      )
  );

  const hasSources = uniqueSources.length > 0;

  return (
    <div className="panel">
      <div className="section-header">
        <div>
          <h2>Retrieved Sources</h2>

          <span className="sources-description">
            Documents and chunks used to generate the answer.
          </span>
        </div>

        {hasSources && (
          <span className="source-count">
            {uniqueSources.length}
          </span>
        )}
      </div>

      {!hasSources ? (
        <div className="empty-sources">
          <div>🔎</div>

          <p>No relevant sources retrieved.</p>

          <small>
            Sources used by the RAG system will appear here
            after you ask a question.
          </small>
        </div>
      ) : (
        <div className="sources">
          {uniqueSources.map((source, index) => (
            <div
              className="source-card"
              key={`${source.source}-${source.chunk_id}-${index}`}
            >
              <div className="source-header">
                <div className="source-document">
                  <span>📄</span>

                  <strong title={source.source}>
                    {source.source}
                  </strong>
                </div>

                <span className="source-number">
                  Source #{index + 1}
                </span>
              </div>

              <div className="source-details">
                <div>
                  <span>Chunk</span>

                  <strong>
                    {source.chunk_id}
                  </strong>
                </div>

                {source.score !== undefined && (
                  <div>
                    <span>Similarity</span>

                    <strong>
                      {typeof source.score === "number"
                        ? source.score.toFixed(4)
                        : source.score}
                    </strong>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Sources;