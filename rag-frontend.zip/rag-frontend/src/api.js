const API_URL =
  import.meta.env.VITE_API_URL || "http://localhost:8000";

export async function askQuestion(sessionId, question) {
  const response = await fetch(`${API_URL}/ask`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      session_id: sessionId,
      question: question
    })
  });

  if (!response.ok) {
    let message = "Failed to get answer.";

    try {
      const errorData = await response.json();

      if (errorData.detail) {
        message = errorData.detail;
      }
    } catch {
      // Keep default error message.
    }

    throw new Error(message);
  }

  return response.json();
}

export async function clearConversation(sessionId) {
  const response = await fetch(`${API_URL}/clear`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      session_id: sessionId
    })
  });

  if (!response.ok) {
    let message = "Failed to clear conversation.";

    try {
      const errorData = await response.json();

      if (errorData.detail) {
        message = errorData.detail;
      }
    } catch {
      // Keep default error message.
    }

    throw new Error(message);
  }

  return response.json();
}

export async function getDocuments() {
  const response = await fetch(`${API_URL}/documents`);

  if (!response.ok) {
    throw new Error("Failed to load documents.");
  }

  return response.json();
}

export function uploadDocument(file, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();

    xhr.open("POST", `${API_URL}/upload`);

    xhr.upload.addEventListener("progress", (event) => {
      if (!event.lengthComputable) {
        return;
      }

      const progress = Math.round(
        (event.loaded / event.total) * 100
      );

      if (onProgress) {
        onProgress(progress);
      }
    });

    xhr.addEventListener("load", () => {
      let data = {};

      try {
        data = JSON.parse(xhr.responseText);
      } catch {
        data = {};
      }

      if (xhr.status >= 200 && xhr.status < 300) {
        if (onProgress) {
          onProgress(100);
        }

        resolve(data);
        return;
      }

      const message =
        data.detail || "Failed to upload file.";

      reject(new Error(message));
    });

    xhr.addEventListener("error", () => {
      reject(
        new Error(
          "Network error while uploading the document."
        )
      );
    });

    xhr.addEventListener("abort", () => {
      reject(
        new Error("Document upload was cancelled.")
      );
    });

    const formData = new FormData();

    formData.append("file", file);

    xhr.send(formData);
  });
}

export async function deleteDocument(filename) {
  const response = await fetch(
    `${API_URL}/documents/${encodeURIComponent(filename)}`,
    {
      method: "DELETE"
    }
  );

  if (!response.ok) {
    let message = "Failed to delete document.";

    try {
      const errorData = await response.json();

      if (errorData.detail) {
        message = errorData.detail;
      }
    } catch {
      // Keep default error message.
    }

    throw new Error(message);
  }

  return response.json();
}