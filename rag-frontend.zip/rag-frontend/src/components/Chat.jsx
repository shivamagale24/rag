import {
  useEffect,
  useRef,
  useState
} from "react";

import ReactMarkdown from "react-markdown";


function formatTime(timestamp) {

  if (!timestamp) {
    return "";
  }

  try {

    return new Date(timestamp).toLocaleTimeString(
      [],
      {
        hour: "2-digit",
        minute: "2-digit"
      }
    );

  } catch {

    return "";

  }
}


function Chat({
  messages,
  question,
  loading,
  onQuestionChange,
  onSend,
  onKeyDown,
  onClear,
  canClear,
  onExampleQuestion
}) {

  const chatEndRef = useRef(null);

  const [copiedIndex, setCopiedIndex] =
    useState(null);


  // =====================================================
  // Auto Scroll
  // =====================================================

  useEffect(() => {

    chatEndRef.current?.scrollIntoView({
      behavior: "smooth"
    });

  }, [messages, loading]);


  // =====================================================
  // Copy Answer
  // =====================================================

  async function handleCopy(text, index) {

    if (!text) {
      return;
    }

    try {

      await navigator.clipboard.writeText(
        text
      );

      setCopiedIndex(index);

      setTimeout(() => {

        setCopiedIndex(null);

      }, 1500);

    } catch {

      setCopiedIndex(null);

    }

  }


  return (

    <div className="panel chat-panel">

      {/* ===============================================
          Header
      =============================================== */}

      <div className="section-header">

        <div>

          <h2>Chat</h2>

          <span className="chat-description">
            Ask questions about your knowledge base.
          </span>

        </div>


        <button
          className="clear-button"
          onClick={onClear}
          disabled={!canClear || loading}
        >
          Clear
        </button>

      </div>


      {/* ===============================================
          Chat Messages
      =============================================== */}

      <div className="chat">

        {messages.length === 0 && !loading ? (

          <div className="empty-chat">

            <div className="empty-chat-icon">
              🤖
            </div>

            <h3>
              Start a conversation
            </h3>

            <p>
              Upload documents and ask questions
              about your knowledge base.
            </p>


            <div className="example-questions">

              <span>
                Try an example:
              </span>


              <button
                type="button"
                onClick={() =>
                  onExampleQuestion(
                    "What information is available in the documents?"
                  )
                }
              >
                What information is available?
              </button>


              <button
                type="button"
                onClick={() =>
                  onExampleQuestion(
                    "What are the main policies mentioned in the documents?"
                  )
                }
              >
                What are the main policies?
              </button>

            </div>

          </div>

        ) : (

          messages.map((message, index) => (

            <div
              key={`${message.role}-${index}`}
              className={`message ${
                message.role === "user"
                  ? "user-message"
                  : "ai-message"
              }`}
            >

              {/* =====================================
                  Message Header
              ===================================== */}

              <div className="message-header">

                <div className="message-role">
                  {message.role === "user"
                    ? "You"
                    : "AI"}
                </div>


                {message.createdAt && (
                  <span className="message-time">
                    {formatTime(
                      message.createdAt
                    )}
                  </span>
                )}

              </div>


              {/* =====================================
                  Message Content
              ===================================== */}

              <div className="message-content">

                {message.role === "assistant" ? (

                  <ReactMarkdown>
                    {message.content}
                  </ReactMarkdown>

                ) : (

                  message.content

                )}

              </div>


              {/* =====================================
                  Copy Button
              ===================================== */}

              {message.role === "assistant" && (
                <button
                  type="button"
                  className="copy-button"
                  onClick={() =>
                    handleCopy(
                      message.content,
                      index
                    )
                  }
                >
                  {copiedIndex === index
                    ? "✓ Copied"
                    : "Copy"}
                </button>
              )}

            </div>

          ))

        )}


        {/* ===========================================
            Loading
        =========================================== */}

        {loading && (

          <div className="message ai-message">

            <div className="message-header">

              <div className="message-role">
                AI
              </div>

              <span className="message-time">
                Now
              </span>

            </div>


            <div className="thinking">

              <span></span>
              <span></span>
              <span></span>

              <span className="thinking-text">
                Thinking...
              </span>

            </div>

          </div>

        )}


        <div ref={chatEndRef}></div>

      </div>


      {/* ===============================================
          Input
      =============================================== */}

      <div className="chat-input">

        <textarea
          placeholder="Ask a question about your documents..."
          value={question}
          onChange={(event) =>
            onQuestionChange(
              event.target.value
            )
          }
          onKeyDown={onKeyDown}
          disabled={loading}
          rows={1}
        />


        <button
          className="send-button"
          onClick={onSend}
          disabled={
            loading ||
            !question.trim()
          }
        >
          {loading ? "..." : "Send"}
        </button>

      </div>


      <p className="input-help">
        Press Enter to send • Shift + Enter for a new line
      </p>

    </div>

  );

}


export default Chat;