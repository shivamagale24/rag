function Upload({
  selectedFile,
  uploadMessage,
  uploading,
  uploadProgress,
  onFileChange,
  onUpload
}) {
  return (
    <div className="panel">
      <h2>Upload Document</h2>

      <div className="upload-box">
        <input
          id="file-input"
          type="file"
          accept=".pdf,.txt,.docx"
          onChange={onFileChange}
          disabled={uploading}
        />

        <p className="file-help">
          Supported: PDF, TXT, DOCX
        </p>

        <p className="file-help">
          Maximum size: 10 MB
        </p>

        {selectedFile && (
          <div className="selected-file">
            <span className="selected-file-icon">
              📄
            </span>

            <div>
              <strong>{selectedFile.name}</strong>

              <small>
                {(
                  selectedFile.size /
                  1024 /
                  1024
                ).toFixed(2)}{" "}
                MB
              </small>
            </div>
          </div>
        )}

        {uploading && (
          <div className="upload-progress">
            <div className="upload-progress-header">
              <span>
                {uploadProgress < 100
                  ? "Uploading..."
                  : "Indexing document..."}
              </span>

              <strong>{uploadProgress}%</strong>
            </div>

            <div className="progress-track">
              <div
                className="progress-bar"
                style={{
                  width: `${uploadProgress}%`
                }}
              ></div>
            </div>
          </div>
        )}

        <button
          className="upload-button"
          onClick={onUpload}
          disabled={!selectedFile || uploading}
        >
          {uploading
            ? uploadProgress < 100
              ? `Uploading ${uploadProgress}%`
              : "Indexing..."
            : "Upload"}
        </button>

        {uploadMessage && (
          <div className="success">
            {uploadMessage}
          </div>
        )}
      </div>
    </div>
  );
}

export default Upload;