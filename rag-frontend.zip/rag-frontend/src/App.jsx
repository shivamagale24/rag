import { useEffect, useState } from "react";
import "./App.css";

import {
  askQuestion,
  clearConversation,
  getDocuments,
  uploadDocument,
  deleteDocument
} from "./api";

import Chat from "./components/Chat";
import Upload from "./components/Upload";
import Documents from "./components/Documents";
import Sources from "./components/Sources";
import ChatHistory from "./components/ChatHistory";

const ALLOWED_FILE_TYPES = [
  "application/pdf",
  "text/plain",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
];

const ALLOWED_EXTENSIONS = [
  ".pdf",
  ".txt",
  ".docx"
];

const MAX_FILE_SIZE =
  10 * 1024 * 1024;

const STORAGE_KEY =
  "enterprise-rag-chat-history";

function createSessionId() {
  return `session-${crypto.randomUUID()}`;
}

function createSession() {
  return {
    id: createSessionId(),
    title: "New conversation",
    messages: [],
    sources: [],
    createdAt: Date.now()
  };
}

function loadStoredSessions() {
  try {
    const stored =
      localStorage.getItem(
        STORAGE_KEY
      );

    if (!stored) {
      return [];
    }

    const parsed =
      JSON.parse(stored);

    if (!Array.isArray(parsed)) {
      return [];
    }

    return parsed;
  } catch {
    return [];
  }
}

function App() {
  const [sessions, setSessions] =
    useState(
      loadStoredSessions
    );

  const [sessionId, setSessionId] =
    useState(() => {
      const storedSessions =
        loadStoredSessions();

      if (
        storedSessions.length > 0
      ) {
        return storedSessions[0].id;
      }

      return createSessionId();
    });

  const [question, setQuestion] =
    useState("");

  const [loading, setLoading] =
    useState(false);

  const [error, setError] =
    useState("");

  const [selectedFile, setSelectedFile] =
    useState(null);

  const [uploadMessage, setUploadMessage] =
    useState("");

  const [uploading, setUploading] =
    useState(false);

  const [uploadProgress, setUploadProgress] =
    useState(0);

  const [documents, setDocuments] =
    useState([]);

  const [documentsLoading, setDocumentsLoading] =
    useState(false);

  const currentSession =
    sessions.find(
      (session) =>
        session.id === sessionId
    ) || {
      id: sessionId,
      title: "New conversation",
      messages: [],
      sources: [],
      createdAt: Date.now()
    };

  const messages =
    currentSession.messages || [];

  const sources =
    currentSession.sources || [];

  useEffect(() => {
    const storedSessions =
      loadStoredSessions();

    if (
      storedSessions.length === 0
    ) {
      const newSession = {
        id: sessionId,
        title: "New conversation",
        messages: [],
        sources: [],
        createdAt: Date.now()
      };

      setSessions([newSession]);
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(sessions)
      );
    } catch {
      // Ignore localStorage errors.
    }
  }, [sessions]);

  useEffect(() => {
    loadDocuments();
  }, []);

  function updateCurrentSession(
    updates
  ) {
    setSessions(
      (previousSessions) => {
        const exists =
          previousSessions.some(
            (session) =>
              session.id ===
              sessionId
          );

        if (!exists) {
          return [
            {
              ...createSession(),
              ...updates,
              id: sessionId
            },
            ...previousSessions
          ];
        }

        return previousSessions.map(
          (session) =>
            session.id ===
            sessionId
              ? {
                  ...session,
                  ...updates
                }
              : session
        );
      }
    );
  }

  async function loadDocuments() {
    setDocumentsLoading(true);

    try {
      const data =
        await getDocuments();

      setDocuments(
        data.documents || []
      );
    } catch (error) {
      setError(error.message);
    } finally {
      setDocumentsLoading(false);
    }
  }

  async function handleSend() {
    if (
      !question.trim() ||
      loading
    ) {
      return;
    }

    const currentQuestion =
      question.trim();

    const timestamp =
      Date.now();

    const userMessage = {
      role: "user",
      content: currentQuestion,
      timestamp
    };

    const updatedMessages = [
      ...messages,
      userMessage
    ];

    updateCurrentSession({
      messages: updatedMessages,

      title:
        messages.length === 0
          ? currentQuestion.slice(
              0,
              45
            ) +
            (
              currentQuestion.length >
              45
                ? "..."
                : ""
            )
          : currentSession.title
    });

    setQuestion("");
    setLoading(true);
    setError("");

    try {
      const data =
        await askQuestion(
          sessionId,
          currentQuestion
        );

      const answer =
        data.answer ||
        "No answer was returned by the RAG system.";

      const assistantMessage = {
        role: "assistant",
        content: answer,
        timestamp: Date.now()
      };

      updateCurrentSession({
        messages: [
          ...updatedMessages,
          assistantMessage
        ],
        sources:
          data.sources || []
      });
    } catch (error) {
      setError(
        error.message
      );
    } finally {
      setLoading(false);
    }
  }

  function handleKeyDown(event) {
    if (
      event.key === "Enter" &&
      !event.shiftKey
    ) {
      event.preventDefault();

      handleSend();
    }
  }

  async function handleClear() {
    if (
      loading ||
      messages.length === 0
    ) {
      return;
    }

    try {
      await clearConversation(
        sessionId
      );

      updateCurrentSession({
        title:
          "New conversation",

        messages: [],

        sources: []
      });

      setQuestion("");
      setError("");
    } catch (error) {
      setError(
        error.message
      );
    }
  }

  function handleNewChat() {
    if (loading) {
      return;
    }

    const newSession =
      createSession();

    setSessions(
      (previousSessions) => [
        newSession,
        ...previousSessions
      ]
    );

    setSessionId(
      newSession.id
    );

    setQuestion("");
    setError("");
  }

  function handleSelectSession(
    id
  ) {
    if (loading) {
      return;
    }

    setSessionId(id);
    setQuestion("");
    setError("");
  }

  function handleExampleQuestion(
    value
  ) {
    setQuestion(value);
  }

  function handleFileChange(
    event
  ) {
    const file =
      event.target.files[0];

    setUploadMessage("");
    setError("");
    setUploadProgress(0);

    if (!file) {
      setSelectedFile(null);
      return;
    }

    const fileName =
      file.name.toLowerCase();

    const hasValidExtension =
      ALLOWED_EXTENSIONS.some(
        (extension) =>
          fileName.endsWith(
            extension
          )
      );

    const hasValidMimeType =
      !file.type ||
      ALLOWED_FILE_TYPES.includes(
        file.type
      );

    if (
      !hasValidExtension ||
      !hasValidMimeType
    ) {
      setSelectedFile(null);

      event.target.value = "";

      setUploadMessage(
        "Unsupported file type. Please select a PDF, TXT, or DOCX file."
      );

      return;
    }

    if (
      file.size >
      MAX_FILE_SIZE
    ) {
      setSelectedFile(null);

      event.target.value = "";

      setUploadMessage(
        "File is too large. Maximum allowed size is 10 MB."
      );

      return;
    }

    setSelectedFile(file);
  }

  async function handleUpload() {
    if (
      !selectedFile ||
      uploading
    ) {
      if (!selectedFile) {
        setUploadMessage(
          "Please select a file first."
        );
      }

      return;
    }

    setUploading(true);
    setUploadProgress(0);
    setUploadMessage("");
    setError("");

    try {
      const data =
        await uploadDocument(
          selectedFile,
          (progress) => {
            setUploadProgress(
              progress
            );
          }
        );

      setUploadMessage(
        data.message ||
          "Document uploaded and indexed successfully."
      );

      setSelectedFile(null);

      const fileInput =
        document.getElementById(
          "file-input"
        );

      if (fileInput) {
        fileInput.value = "";
      }

      await loadDocuments();
    } catch (error) {
      setError(
        error.message
      );
    } finally {
      setUploading(false);
    }
  }

  async function handleDelete(
    filename
  ) {
    if (loading) {
      return;
    }

    const shouldDelete =
      window.confirm(
        `Are you sure you want to delete "${filename}"?`
      );

    if (!shouldDelete) {
      return;
    }

    setError("");

    try {
      await deleteDocument(
        filename
      );

      setDocuments(
        (previousDocuments) =>
          previousDocuments.filter(
            (document) =>
              document.filename !==
              filename
          )
      );

      updateCurrentSession({
        sources:
          sources.filter(
            (source) =>
              source.source !==
              filename
          )
      });
    } catch (error) {
      setError(
        error.message
      );
    }
  }

  return (
    <div className="app">
      <header className="app-header">
        <div>
          <h1>
            Enterprise RAG
          </h1>

          <p>
            Ask questions and get
            answers from your
            knowledge base.
          </p>
        </div>

        <button
          className="new-chat-button"
          onClick={handleNewChat}
          disabled={loading}
        >
          + New Chat
        </button>
      </header>

      <div className="main-layout">
        <aside className="sidebar">
          <Upload
            selectedFile={
              selectedFile
            }
            uploadMessage={
              uploadMessage
            }
            uploading={
              uploading
            }
            uploadProgress={
              uploadProgress
            }
            onFileChange={
              handleFileChange
            }
            onUpload={
              handleUpload
            }
          />

          <Documents
            documents={
              documents
            }
            loading={
              documentsLoading
            }
            onDelete={
              handleDelete
            }
          />

          <ChatHistory
            sessions={
              sessions
            }
            currentSessionId={
              sessionId
            }
            onSelect={
              handleSelectSession
            }
            onNewChat={
              handleNewChat
            }
          />
        </aside>

        <main className="content">
          <div className="session-banner">
            <div>
              <span>
                Current conversation
              </span>

              <strong>
                {
                  currentSession.title
                }
              </strong>
            </div>

            <small>
              Session ID:{" "}
              {sessionId}
            </small>
          </div>

          {error && (
            <div className="error">
              <strong>
                Error:
              </strong>{" "}
              {error}
            </div>
          )}

          <Chat
            messages={
              messages
            }
            question={
              question
            }
            loading={
              loading
            }
            onQuestionChange={
              setQuestion
            }
            onSend={
              handleSend
            }
            onKeyDown={
              handleKeyDown
            }
            onClear={
              handleClear
            }
            canClear={
              messages.length >
              0
            }
            onExampleQuestion={
              handleExampleQuestion
            }
          />

          <Sources
            sources={sources}
          />
        </main>
      </div>
    </div>
  );
}

export default App;